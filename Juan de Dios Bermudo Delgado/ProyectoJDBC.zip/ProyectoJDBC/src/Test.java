import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Test {

	public void conectorDataBAse() {
		try {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException ex) {
				System.out.println("ERror al registrar el driver de MySQL: " + ex);
			}
			Connection connection = null;
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prueba", "root", "");
			boolean valid = connection.isValid(5000);

			// insertaRegistro(connection);
			// actualizaRegistro(connection);
			// borraRegistro(connection);
			// selectRegistros(connection);
			System.out.println(valid ? "TEST OK" : "TEST FAIL");
		} catch (java.sql.SQLException sqle) {
			System.out.println("Error " + sqle);
		}
	}

	// public static void main(String[] args) {
	// // TODO Auto-generated method stub
	// Test javaMySQLBasics = new Test();
	// javaMySQLBasics.conectorDataBAse();
	// }

	public void insertaRegistro(Connection conn) throws SQLException {
		String sql = "INSERT INTO usuario (user,pass,nombre,correo) VALUES(?,?,?,?)";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, "paco1234");
		statement.setString(2, "pacoPass");
		statement.setString(3, "pacoNombre");
		statement.setString(4, "paco@hotmail.com");

		int rowsInserted = statement.executeUpdate();
		if (rowsInserted > 0) {
			System.out.println("Usuario insertado");
		}
	}

	public void actualizaRegistro(Connection conn) throws SQLException {
		String sql = "UPDATE usuario SET user=?, pass=?, correo=? WHERE nombre=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, "Juan1234");
		statement.setString(2, "JuanPass");
		statement.setString(4, "pacoNombre");
		statement.setString(3, "Juan@hotmail.com");

		int rowsUpdated = statement.executeUpdate();
		if (rowsUpdated > 0) {
			System.out.println("Actualizacion realizada");
		}

	}

	public void borraRegistro(Connection conn) throws SQLException {
		String sql = "DELETE FROM usuario where user=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, "Juan1234");
		int rowsDeleted = statement.executeUpdate();
		if (rowsDeleted > 0) {
			System.out.println("Eleminaci�n realizada");
		}

	}

	public void selectRegistros(Connection conn) throws SQLException {
		String sql = "SELECT * FROM usuario";
		PreparedStatement statement = conn.prepareStatement(sql);
		ResultSet result = statement.executeQuery(sql);

		int count = 0;
		while (result.next()) {
			String pass = result.getString(2);
			String usuario = result.getString(3);
			String nombre = result.getString("nombre");
			String correo = result.getString("correo");
			count++;
			System.out.println("-- " + count + " " + pass + " " + usuario + " " + nombre + " " + correo);
		}

	}

	public void insertaCoche(Connection conn) throws SQLException {
		String sql = "INSERT INTO usuario (user,pass,nombre,correo) VALUES(?,?,?,?)";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, "paco1234");
		statement.setString(2, "pacoPass");
		statement.setString(3, "pacoNombre");
		statement.setString(4, "paco@hotmail.com");

		int rowsInserted = statement.executeUpdate();
		if (rowsInserted > 0) {
			System.out.println("Usuario insertado");
		}
	}

	public void actualizaCoche(Connection conn) throws SQLException {
		String sql = "UPDATE usuario SET user=?, pass=?, correo=? WHERE nombre=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, "Juan1234");
		statement.setString(2, "JuanPass");
		statement.setString(4, "pacoNombre");
		statement.setString(3, "Juan@hotmail.com");

		int rowsUpdated = statement.executeUpdate();
		if (rowsUpdated > 0) {
			System.out.println("Actualizacion realizada");
		}

	}

	public void borraCoche(Connection conn) throws SQLException {
		String sql = "DELETE FROM usuario where user=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, "Juan1234");
		int rowsDeleted = statement.executeUpdate();
		if (rowsDeleted > 0) {
			System.out.println("Eleminaci�n realizada");
		}

	}

	public void selectCoche(Connection conn) throws SQLException {
		String sql = "SELECT * FROM usuario";
		PreparedStatement statement = conn.prepareStatement(sql);
		ResultSet result = statement.executeQuery(sql);

		int count = 0;
		while (result.next()) {
			String pass = result.getString(2);
			String usuario = result.getString(3);
			String nombre = result.getString("nombre");
			String correo = result.getString("correo");
			count++;
			System.out.println("-- " + count + " " + pass + " " + usuario + " " + nombre + " " + correo);
		}

	}

}
