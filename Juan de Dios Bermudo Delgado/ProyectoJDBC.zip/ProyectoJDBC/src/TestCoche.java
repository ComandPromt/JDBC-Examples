
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Scanner;

public class TestCoche {

	private static Timestamp getCurretnTimestamp() {
		java.util.Date hoy = new java.util.Date();
		return new java.sql.Timestamp(hoy.getTime());
	}

	Timestamp fecha = getCurretnTimestamp();

	private int id;
	private String marca, modelo, color, matricula, nombre;
	private Double precio;

	public void conectorDataBaseCoche() {
		try {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException ex) {
				System.out.println("ERror al registrar el driver de MySQL: " + ex);
			}
			Connection connection = null;
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prueba", "root", "");
			boolean valid = connection.isValid(5000);
			Scanner entrada = new Scanner(System.in);
			int num;
			do {
				System.out.println("Opciones del menu:\n"
						+ "\t 1.Introducir coche\n \t 2.Actualizar coche\n \t 3.Eliminar un coche\n \t 4.Ver coches\n \t 5.Insertar clientes\n \t 6.Comprar Coche\n \t 7.Lista de coches comprados\n \t 0.Salir");
				System.out.print("Introduzca el numero de la opcion: ");
				num = entrada.nextInt();
				entrada.nextLine();
				switch (num) {
				case 1:
					System.out.println("Introduzca la marca: ");
					marca = entrada.nextLine();
					System.out.println("Introduzca la modelo: ");
					modelo = entrada.nextLine();
					System.out.println("Introduzca la color: ");
					color = entrada.nextLine();
					System.out.println("Introduzca la matricula: ");
					matricula = entrada.nextLine();
					System.out.println("Introduzca la precio: ");
					precio = entrada.nextDouble();
					entrada.nextLine();
					insertaCoche(connection, marca, modelo, color, matricula, precio);
					break;
				case 2:
					System.out.println("Introduzca la marca: ");
					marca = entrada.nextLine();
					System.out.println("Introduzca la modelo: ");
					modelo = entrada.nextLine();
					System.out.println("Introduzca la color: ");
					color = entrada.nextLine();
					System.out.println("Introduzca la matricula: ");
					matricula = entrada.nextLine();
					System.out.println("Introduzca la precio: ");
					precio = entrada.nextDouble();
					entrada.nextLine();
					actualizaCoche(connection, marca, modelo, color, matricula, precio);
					break;
				case 3:
					System.out.println("Introduzca la matricula: ");
					matricula = entrada.nextLine();
					borraCoche(connection, matricula);
					break;
				case 4:
					selectCoche(connection);
					break;
				case 5:
					System.out.println("Introduzca el id cliente: ");
					id = entrada.nextInt();
					entrada.nextLine();
					System.out.println("Introduzca el nombre de cliente: ");
					nombre = entrada.nextLine();
					insertaCliente(connection, nombre, id);
					break;
				case 6:
					System.out.println("Introduzca el id cliente: ");
					id = entrada.nextInt();
					entrada.nextLine();
					System.out.println("Introduzca la matricula del coche: ");
					matricula = entrada.nextLine();
					comprarCoche(connection, matricula, id);
					break;
				case 7:
					listaCocheComprados(connection);
					break;
				default:
					break;
				}
			} while (num != 0);
			System.out.println(valid ? "TEST OK" : "TEST FAIL");
		} catch (java.sql.SQLException sqle) {
			System.out.println("Error " + sqle);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestCoche javaMySQLBasics = new TestCoche();
		javaMySQLBasics.conectorDataBaseCoche();

	}

	public void insertaCoche(Connection conn, String marca, String modelo, String color, String matricula,
			Double precio) throws SQLException {
		String sql = "INSERT INTO coche (marca,modelo,color,matricula,precio,fechaDeCompra) VALUES(?,?,?,?,?,?)";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, marca);
		statement.setString(2, modelo);
		statement.setString(3, color);
		statement.setString(4, matricula);
		statement.setDouble(5, precio);
		statement.setTimestamp(6, fecha);
		int rowsInserted = statement.executeUpdate();
		if (rowsInserted > 0) {
			System.out.println("Coche insertado");
		}
	}

	public void insertaCliente(Connection conn, String nombre, int id) throws SQLException {
		String sql = "INSERT INTO cliente (id,nombre) VALUES(?,?)";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setInt(1, id);
		statement.setString(2, nombre);
		int rowsInserted = statement.executeUpdate();
		if (rowsInserted > 0) {
			System.out.println("Cliente insertado");
		}
	}

	public void actualizaCoche(Connection conn, String marca, String modelo, String color, String matricula,
			Double precio) throws SQLException {
		Coche coche2 = new Coche("Ford", "Mustang", "negro", "1234ASF", 30000.99);
		String sql = "UPDATE coche SET marca=?, modelo=?, color=?, precio=?, fechaDeCompra=? WHERE matricula=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, marca);
		statement.setString(2, modelo);
		statement.setString(3, color);
		statement.setString(6, matricula);
		statement.setDouble(4, precio);
		statement.setTimestamp(5, fecha);

		int rowsUpdated = statement.executeUpdate();
		if (rowsUpdated > 0) {
			System.out.println("Actualizacion realizada");
		}

	}

	public void borraCoche(Connection conn, String matricula) throws SQLException {
		String sql = "DELETE FROM coche where matricula=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, matricula);
		int rowsDeleted = statement.executeUpdate();
		if (rowsDeleted > 0) {
			System.out.println("Eliminaci�n realizada");
		}

	}

	public void selectCoche(Connection conn) throws SQLException {
		String sql = "SELECT * FROM coche";
		PreparedStatement statement = conn.prepareStatement(sql);
		ResultSet result = statement.executeQuery(sql);

		int count = 0;
		while (result.next()) {
			String marca = result.getString(1);
			String modelo = result.getString(2);
			String color = result.getString("color");
			String matricula = result.getString("matricula");
			Double precio = result.getDouble("precio");
			Date fecha = result.getDate("fechaDeCompra");
			count++;
			System.out.println("-- " + count + " " + marca + " " + modelo + " " + color + " " + matricula + " " + precio
					+ " " + fecha);
		}

	}

	public void comprarCoche(Connection conn, String matricula, int id) throws SQLException {
		String sql = "SELECT id FROM `coche` WHERE matricula='4562loo'";
		PreparedStatement statement = conn.prepareStatement(sql);

		ResultSet result = statement.executeQuery(sql);
		int marca = result.getInt(1);
		if (marca == 0) {
			String sql1 = "UPDATE coche SET id=? WHERE matricula=?";
			PreparedStatement statement1 = conn.prepareStatement(sql1);
			statement1.setInt(1, id);
			statement1.setString(2, matricula);
			statement1.executeQuery(sql1);
			System.out.println("Compra realizada");
		} else {
			System.out.println("Este coche ya esta comprado");
		}

	}

	public void listaCocheComprados(Connection conn) throws SQLException {
		String sql = "SELECT * FROM coche where id>0";
		PreparedStatement statement = conn.prepareStatement(sql);
		ResultSet result = statement.executeQuery(sql);

		int count = 0;
		while (result.next()) {
			String marca = result.getString(1);
			String modelo = result.getString(2);
			String color = result.getString("color");
			String matricula = result.getString("matricula");
			Double precio = result.getDouble("precio");
			Date fecha = result.getDate("fechaDeCompra");
			count++;
			System.out.println("-- " + count + " " + marca + " " + modelo + " " + color + " " + matricula + " " + precio
					+ " " + fecha);
		}

	}

}
